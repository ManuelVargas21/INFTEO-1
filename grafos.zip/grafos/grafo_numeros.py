import tkinter as tk
import time
import threading

class GrafoNumeros:
    def __init__(self, root):
        self.root = root
        self.root.title("Grafo de números (1, 2, 3, 4, 5)")
        self.canvas = tk.Canvas(root, width=500, height=400, bg="white")
        self.canvas.pack()

        # Nodos y coordenadas iniciales
        self.nodes = {
            "1": (100, 150),
            "2": (400, 150),
            "3": (250, 80),
            "4": (150, 300),
            "5": (350, 300)
        }

        # Aristas iniciales
        self.edges = [
            ("1", "2"), ("1", "4"), ("2", "5"),
            ("3", "2"), ("3", "4"), ("4", "5"), ("3", "1")
        ]

        # Almacenaremos los objetos de nodos y texto
        self.node_objs = {}
        self.text_objs = {}
        self.dibujar_grafo()

        # Controles
        self.frame = tk.Frame(root)
        self.frame.pack(pady=10)

        # Entrada para recorrido
        tk.Label(self.frame, text="Recorrido (ej. 1, 2, 3, 4, 5):").grid(row=0, column=0, padx=5)
        self.recorrido_input = tk.StringVar(value="1, 2, 3, 4, 5")
        self.entry_recorrido = tk.Entry(self.frame, textvariable=self.recorrido_input, width=20, justify="center")
        self.entry_recorrido.grid(row=0, column=1, padx=5)

        # Botón para iniciar el recorrido
        self.btn_iniciar = tk.Button(self.frame, text="Iniciar recorrido", command=self.iniciar_recorrido)
        self.btn_iniciar.grid(row=0, column=2, padx=5)

        # Etiqueta para mostrar el estado
        self.lbl_estado = tk.Label(root, text="Esperando inicio...", font=("Arial", 12))
        self.lbl_estado.pack()

        # Etiqueta para mostrar el tiempo
        self.lbl_tiempo = tk.Label(root, text="Tiempo recorrido: 0.0 segundos", font=("Arial", 10))
        self.lbl_tiempo.pack()

    def dibujar_grafo(self):
        # Dibuja las aristas
        for e1, e2 in self.edges:
            x1, y1 = self.nodes[e1]
            x2, y2 = self.nodes[e2]
            self.canvas.create_line(x1, y1, x2, y2, width=3)

        # Dibuja los nodos
        for n, (x, y) in self.nodes.items():
            nodo = self.canvas.create_oval(x-25, y-25, x+25, y+25, fill="lightgray", width=2)
            texto = self.canvas.create_text(x, y, text=n, font=("Arial", 20, "bold"))
            self.node_objs[n] = nodo
            self.text_objs[n] = texto

    def iniciar_recorrido(self):
        # Obtener el recorrido del usuario
        recorrido_input = self.recorrido_input.get().strip()

        # Convertir la entrada a una lista de nodos
        try:
            recorrido = [nodo.strip() for nodo in recorrido_input.split(",") if nodo.strip() in self.nodes]
        except Exception as e:
            self.lbl_estado.config(text="⚠️ Error en el formato del recorrido.", fg="red")
            return

        # Verificar que todos los nodos son válidos
        if len(recorrido) != len(set(recorrido)) or any(nodo not in self.nodes for nodo in recorrido):
            self.lbl_estado.config(text="⚠️ Algunos nodos no son vAlidos (usa 1, 2, 3, 4, 5).", fg="red")
            return

        self.lbl_estado.config(text=f"Recorriendo: {', '.join(recorrido)}", fg="black")

        # Iniciar el recorrido en un hilo para no bloquear la interfaz
        threading.Thread(target=self.recorrer_grafo, args=(recorrido,), daemon=True).start()

    def recorrer_grafo(self, recorrido):
        start_time = time.time()

        for i in range(len(recorrido) - 1):
            nodo_actual = recorrido[i]
            nodo_siguiente = recorrido[i + 1]
            self.iluminar_nodo(nodo_actual)

            # Resaltar la línea de la arista entre los nodos
            self.resaltar_arista(nodo_actual, nodo_siguiente)

            self.lbl_estado.config(text=f"Visitando nodo: {nodo_actual} -> {nodo_siguiente}")
            self.root.update()
            time.sleep(1)

            self.restaurar_nodo(nodo_actual)
            self.restaurar_arista(nodo_actual, nodo_siguiente)

        # Al final, iluminar el último nodo
        self.iluminar_nodo(recorrido[-1])
        self.lbl_estado.config(text=f"Visitando nodo: {recorrido[-1]}")
        self.root.update()
        time.sleep(1)
        self.restaurar_nodo(recorrido[-1])

        end_time = time.time()
        total_time = end_time - start_time
        self.lbl_estado.config(text="Recorrido finalizado ✅", fg="green")
        self.lbl_tiempo.config(text=f"Tiempo recorrido: {total_time:.2f} segundos")

    def iluminar_nodo(self, nodo):
        self.canvas.itemconfig(self.node_objs[nodo], fill="blue")
        self.canvas.itemconfig(self.text_objs[nodo], text="X", fill="white")

    def restaurar_nodo(self, nodo):
        self.canvas.itemconfig(self.node_objs[nodo], fill="lightgray")
        self.canvas.itemconfig(self.text_objs[nodo], text=nodo, fill="black")

    def resaltar_arista(self, nodo1, nodo2):
        # Resalta la línea entre nodo1 y nodo2
        x1, y1 = self.nodes[nodo1]
        x2, y2 = self.nodes[nodo2]
        self.canvas.create_line(x1, y1, x2, y2, width=5, fill="red", tags="highlighted_line")

    def restaurar_arista(self, nodo1, nodo2):
        # Restaura la línea entre nodo1 y nodo2 a su color original
        x1, y1 = self.nodes[nodo1]
        x2, y2 = self.nodes[nodo2]
        self.canvas.create_line(x1, y1, x2, y2, width=3)

        # Eliminar la línea resaltada de la pantalla
        self.canvas.delete("highlighted_line")

root = tk.Tk()
app = GrafoNumeros(root)
root.mainloop()

