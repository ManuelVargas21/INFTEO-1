import networkx as nx
import matplotlib.pyplot as plt
import time

# === Crear la figura y grafo ===
fig = plt.figure(figsize=(8, 8))
ax = plt.subplot(111)
ax.set_title('Grafo con letras (a, b, c, d)', fontsize=12)

G = nx.Graph()
nodos = ['a', 'b', 'c', 'd']
G.add_nodes_from(nodos)
G.add_edges_from([
    ('a', 'b'), ('b', 'c'), ('c', 'd'),
    ('a', 'd'), ('a', 'c'), ('b', 'd')
])
pos = {'a': (0, 1), 'b': (1, 1), 'c': (1, 0), 'd': (0, 0)}

plt.ion()  # modo interactivo

while True:
    # Preguntar tipo de recorrido y nodo inicial
    tipo = input("¿Qué recorrido deseas ver? (BFS/DFS) o 'salir' para terminar: ").strip().upper()
    if tipo == 'SALIR':
        break

    inicio = input("Nodo inicial (a, b, c, d): ").strip().lower()

    # Calcular el recorrido
    try:
        if tipo == "BFS":
            recorrido = list(nx.bfs_tree(G, source=inicio).nodes())
        elif tipo == "DFS":
            recorrido = list(nx.dfs_tree(G, source=inicio).nodes())
        else:
            print("Tipo no válido, usando DFS por defecto.")
            recorrido = list(nx.dfs_tree(G, source=inicio).nodes())
    except nx.NetworkXError:
        print("⚠️ Nodo inválido, usando 'a' como inicio.")
        inicio = 'a'
        recorrido = list(nx.bfs_tree(G, source=inicio).nodes())

    print("\nOrden del recorrido:", recorrido)

    # Animación del recorrido
    visitados = set()
    aristas_recorridas = []

    for i, nodo in enumerate(recorrido):
        ax.clear()
        visitados.add(nodo)

        if i > 0:
            aristas_recorridas.append((recorrido[i-1], nodo))

        # Colorear nodos
        colores_nodos = []
        for n in G.nodes():
            if n == nodo:
                colores_nodos.append('red')
            elif n in visitados:
                colores_nodos.append('skyblue')
            else:
                colores_nodos.append('lightgray')

        # Colorear aristas
        colores_aristas = []
        for edge in G.edges():
            if edge in aristas_recorridas or (edge[1], edge[0]) in aristas_recorridas:
                colores_aristas.append('red')
            else:
                colores_aristas.append('black')

        # Dibujar grafo
        nx.draw(
            G, pos,
            with_labels=True,
            node_color=colores_nodos,
            node_size=2000,
            font_size=14,
            font_weight='bold',
            edgecolors='black',
            edge_color=colores_aristas,
            width=3,
            ax=ax
        )

        ax.set_title(f"Paso {i+1}: visitando '{nodo.upper()}'", fontsize=14)
        plt.pause(1.2)

plt.ioff()
plt.show()
print("¡Programa terminado!")
