import networkx as nx
import matplotlib.pyplot as plt
import time

# === Crear la figura ===
fig = plt.figure(figsize=(8, 8))
ax = plt.subplot(111)
ax.set_title('Grafo con números (1–5)', fontsize=12)

# === Crear grafo ===
G = nx.Graph()
G.add_nodes_from([1, 2, 3, 4, 5])
G.add_edges_from([
    (1, 2),
    (1, 4),
    (2, 3),
    (3, 4),
    (2, 5),
    (4, 5)
])
pos = {
    1: (0, 1),
    2: (1, 1),
    3: (0.5, 0.55),
    4: (0, 0),
    5: (1, 0)
}

plt.ion()  # modo interactivo

while True:
    # Pedir tipo de recorrido
    tipo = input("¿Qué recorrido deseas ver? (BFS/DFS) o 'salir' para terminar: ").strip().upper()
    if tipo == 'SALIR':
        break

    # Pedir nodo inicial
    try:
        inicio = int(input("Nodo inicial (1–5): ").strip())
    except ValueError:
        print("Entrada inválida, usando 1 por defecto.")
        inicio = 1

    # Calcular recorrido
    try:
        if tipo == "BFS":
            recorrido = list(nx.bfs_tree(G, source=inicio).nodes())
        elif tipo == "DFS":
            recorrido = list(nx.dfs_tree(G, source=inicio).nodes())
        else:
            print("Tipo no válido, usando DFS por defecto.")
            recorrido = list(nx.dfs_tree(G, source=inicio).nodes())
    except nx.NetworkXError:
        print("Nodo inválido, usando 1 como inicio.")
        inicio = 1
        recorrido = list(nx.bfs_tree(G, source=inicio).nodes())

    print("\nOrden del recorrido:", recorrido)

    # Animación del recorrido
    visitados = set()
    aristas_recorridas = []

    for i, nodo in enumerate(recorrido):
        ax.clear()
        visitados.add(nodo)

        # Resaltar arista anterior
        if i > 0:
            aristas_recorridas.append((recorrido[i-1], nodo))

        # Colores de nodos
        colores_nodos = []
        for n in G.nodes():
            if n == nodo:
                colores_nodos.append('red')        # nodo actual
            elif n in visitados:
                colores_nodos.append('skyblue')    # ya visitado
            else:
                colores_nodos.append('lightgray')  # no visitado

        # Colores de aristas
        colores_aristas = []
        for edge in G.edges():
            if edge in aristas_recorridas or (edge[1], edge[0]) in aristas_recorridas:
                colores_aristas.append('red')
            else:
                colores_aristas.append('black')

        nx.draw(
            G, pos,
            with_labels=True,
            node_color=colores_nodos,
            node_size=2000,
            font_size=14,
            font_weight='bold',
            edgecolors='black',
            edge_color=colores_aristas,
            width=3,
            ax=ax
        )

        ax.set_title(f"Paso {i+1}: visitando '{nodo}'", fontsize=14)
        plt.pause(1.2)

print("¡Programa terminado!")
plt.ioff()
plt.show()


