R = {(1, 2), (2, 3), (1, 3)}

print("Resultado de transitiva")

print("Relación definida:", R)

def verificar_transitiva(R):
    for (a, b) in R:
        for (x, c) in R:
            if b == x and (a, c) not in R:
                print(f"Verificacion fallida")
                return False
    print("Verificacion exitosa")
    return True


verificar_transitiva(R)