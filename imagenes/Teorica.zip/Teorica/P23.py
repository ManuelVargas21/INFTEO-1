def es_reflexiva(relacion, conjunto):
    for a in conjunto:
        if (a, a) not in relacion:
            return False
    return True

def es_simetrica(relacion):
    for (a, b) in relacion:
        if (b, a) not in relacion:
            return False
    return True

def es_transitiva(relacion):
    for (a, b) in relacion:
        for (c, d) in relacion:
            if b == c and (a, d) not in relacion:
                return False
    return True

def es_equivalencia(relacion, conjunto):
    return (
        es_reflexiva(relacion, conjunto) and
        es_simetrica(relacion) and
        es_transitiva(relacion)
    )

conjunto = {1, 2, 3}
relacion = {(1,1), (2,2), (3,3), (1,2), (2,1), (2,3), (3,2)}

resultado = es_equivalencia(relacion, conjunto)
print("¿La relación es de equivalencia?", resultado)