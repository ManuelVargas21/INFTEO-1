A = {3, 7, 9, 12}

print("Resultado de Cardinalidad")

print("Conjunto Generado es:", A)

cardinalidad = len(A)
print("La cardinalidad es:", cardinalidad)

def verificar_cardinalidad(conjunto, esperado):
    return len(conjunto) == esperado

esperado = 4

if verificar_cardinalidad(A, esperado):
    print("Verificacion exitosa")
else:
    print("Verificacion fallida")