A = set(range(1, 6)) 

print("Resultado de equivalencia")

R = {(a, a) for a in A} | {(a, b) for a in A for b in A if a % 2 == b % 2}

def verificar_equivalencia(A, R):
    for a in A:
        if (a, a) not in R:
            return False
    for (a, b) in R:
        if (b, a) not in R:
            return False
    for (a, b) in R:
        for (x, c) in R:
            if b == x and (a, c) not in R:
                return False
    return True


print("Verificacion exitosa:", verificar_equivalencia(A, R))