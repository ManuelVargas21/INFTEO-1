A = set(range(1, 6))

print("Resultado de orden")

print("Conjunto Generado es: " , A)

R = {(a, b) for a in A for b in A if a <= b}

def verificar_orden(A, R):
    for a in A:
        if (a, a) not in R:
            return False
    for (a, b) in R:
        if (b, a) in R and a != b:
            return False
    for (a, b) in R:
        for (x, c) in R:
            if b == x and (a, c) not in R:
                return False
    return True

print("Verificacion exitosa:", verificar_orden(A, R))