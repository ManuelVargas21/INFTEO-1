A = set(range(1, 51))
B = set(range(25, 76))

print("Resultado Union")

print("Conjunto A:", A)
print("Conjunto B:", B)

union = A | B

print("Conjunto Union A | B:", union)

def verificar_union(A, B, resultado):
    return resultado == A.union(B)


if verificar_union(A, B, union):
    print("Verificacion exitosa")
else:
    print("Verificacion fallida")