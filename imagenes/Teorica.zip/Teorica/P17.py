print("Resultado de funcion inyectiva")
def f(x):
    return 2 * x

dominio = range(1, 6)

imagen = [f(x) for x in dominio]

def es_inyectiva(imagen):
    return len(imagen) == len(set(imagen))


print("Verificacion exitosa:", es_inyectiva(imagen))