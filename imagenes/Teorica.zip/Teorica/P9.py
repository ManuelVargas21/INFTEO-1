U = set(range(1, 101))    
A = set(range(25, 76))    

print("Resultado de Complemento")

print("Universo U:", U)
print("Conjunto A:", A)

complemento = U - A

print("Complemento de A en U (U - A):", complemento)

def verificar_complemento(U, A, resultado):
    union_total = A | resultado
    interseccion = A & resultado
    return union_total == U and len(interseccion) == 0

if verificar_complemento(U, A, complemento):
    print("Verificacion exitosa")
else:
    print("Verificacion fallida")