A = set(range(1, 6)) 

R = {(1, 2), (3, 4)} 

print("Resultado de Clausura Simétrica")

print("Conjunto A:", A)
print("Relación inicial R:", R)

def clausura_simetrica(R):
    return R | {(b, a) for (a, b) in R}

def es_simetrica(R):
    for (a, b) in R:
        if (b, a) not in R:
            print(f"Verificacion fallida")
            return False
    print("Verificacion exitosa")
    return True

R_simetrica = clausura_simetrica(R)
es_simetrica(R_simetrica)