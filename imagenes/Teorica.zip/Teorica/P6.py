A = set(range(1, 51)) 
B = set(range(25, 76)) 

print("Resultado de Interseccion")

print("Conjunto A:", A)
print("Conjunto B:", B)

interseccion = A & B

print("Conjunto Intersección A & B:", interseccion)

def verificar_interseccion(A, B, resultado):
    return resultado == A.intersection(B)

if verificar_interseccion(A, B, interseccion):
    print("Verificacion exitosa")
else:
    print("Verificacion fallida")