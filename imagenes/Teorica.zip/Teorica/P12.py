relacion = {(1, 2), (2, 1), (3, 3), (4, 5), (5, 4)} 

print("Resultado de Simetrica")

print("Relación definida:", relacion)

def verificar_simetrica(relacion):
    for (a, b) in relacion:
        if (b, a) not in relacion:
            print(f"Verificacion fallida")
            return False
    print("Verificacion exitosa")
    return True

verificar_simetrica(relacion)