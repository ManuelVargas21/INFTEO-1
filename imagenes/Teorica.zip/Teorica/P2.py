pares = {x for x in range(1, 21) if x % 2 == 0}

print("Resultado de Compresion")

print("Conjunto generado es:", pares)

def comparar(conjunto):
    esperado = set(range(2, 21, 2))
    
    return conjunto == esperado

if comparar(pares):
    print("Verificacion exitosa")
    
else:
    print("Verificacion fallida")
