A = {1, 2, 3, 4}

print("Resultado de Extension")

print("El conjunto Generado es:", A)

print("El tipo de la variable A es:", type(A))
print("\n" + "="*30 + "\n")

def verificar_extension(conjunto):
    
    elementos = {1, 2, 3, 4}

    if conjunto == elementos:

        print("Verificacion exitosa")
    else:
        print(f"Verificacion fallida")

print("Metodo de verificacion")
verificar_extension(A)
