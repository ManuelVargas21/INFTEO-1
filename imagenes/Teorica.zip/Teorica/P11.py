A = set(range(1, 6))  

print("Resultado de relación Reflexiva")
print("Conjunto A:", A)

relacion = {(a, a) for a in A}

print("Relación reflexiva generada:", relacion)

def verificar_reflexiva(A, relacion):
    for a in A:
        if (a, a) not in relacion:
            print(f"Verificacion fallida")
            return False
    print("Verificacion exitosa")
    return True

verificar_reflexiva(A, relacion)