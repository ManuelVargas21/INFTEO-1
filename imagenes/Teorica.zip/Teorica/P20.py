A = set(range(1, 6))

R = {(1, 2), (2, 3), (3, 4), (4, 5)}

print("Resultado de clausura reflexiva")

print("Conjunto A:", A)
print("Relación inicial R:", R)

R_reflexiva = R | {(a, a) for a in A}

def es_reflexiva(A, R):
    return all((a, a) in R for a in A)

print("Verificacion exitosa:", es_reflexiva(A, R_reflexiva))