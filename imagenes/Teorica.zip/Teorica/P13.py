R = {(1, 2), (2, 2)}

print("Resultado de antisimetrica")

print("Relación definida:", R)

def verificar_antisimetrica(R):
    for (a, b) in R:
        if (b, a) in R and a != b:
            print(f"Verificacion fallida")
            return False
    print("Verificacion exitosa")
    return True

verificar_antisimetrica(R)