A = set(range(1, 51))    
B = set(range(25, 76))    

print("Resultado de Simetrica")
print("Conjunto A:", A)
print("Conjunto B:", B)


diferencia_simetrica = A ^ B

print("Conjunto Diferencia Simétrica A ^ B:", diferencia_simetrica)


def verificar_diferencia_simetrica(A, B, resultado):
    return resultado == A.symmetric_difference(B)


if verificar_diferencia_simetrica(A, B, diferencia_simetrica):
    print("Verificacion exitosa")
else:
    print("Verificacion fallida")