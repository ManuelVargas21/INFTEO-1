
A = set(range(1, 51))     
B = set(range(25, 76))    

print("Resultado de Diferencia")

print("Conjunto A:", A)
print("Conjunto B:", B)

diferencia = A - B

print("Conjunto Diferencia A - B:", diferencia)


def verificar_diferencia(A, B, resultado):
    return resultado == A.difference(B)

if verificar_diferencia(A, B, diferencia):
    print("Verificacion exitosa")
else:
    print("Verificacion fallida")