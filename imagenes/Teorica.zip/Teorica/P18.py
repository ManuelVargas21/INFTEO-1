print("Resultado de funcion sobreyectiva")
def f(x):
    return x % 3

A = range(10)   
B = {0, 1, 2}     

imagen = [f(x) for x in A]

def es_sobreyectiva(B, imagen):
    return B.issubset(set(imagen))

print("Verificacion exitosa:", es_sobreyectiva(B, imagen))