A = set(range(1, 6)) 
B = set(range(10, 16))

print("Resultado de Cartesiano")

print("Conjunto A:", A)
print("Conjunto B:", B)

producto_cartesiano = {(a, b) for a in A for b in B}

print("Producto cartesiano A × B:", producto_cartesiano)

def verificar_producto_cartesiano(A, B, resultado):
    return len(resultado) == len(A) * len(B)


if verificar_producto_cartesiano(A, B, producto_cartesiano):
    print("Verificacion exitosa")
else:
    print("Verificacion fallida")