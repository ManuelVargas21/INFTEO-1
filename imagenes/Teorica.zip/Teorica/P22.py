A = set(range(1, 6))  

R = {(1, 2), (2, 3)}  

print("Resultado de Clausura Transitiva")

print("Conjunto A:", A)
print("Relación inicial R:", R)

def clausura_transitiva(R):
    nueva = set(R)
    while True:
        agregado = False
        pares_actuales = list(nueva)
        for (a, b) in pares_actuales:
            for (x, c) in pares_actuales:
                if b == x and (a, c) not in nueva:
                    nueva.add((a, c))
                    agregado = True
        if not agregado:
            break
    return nueva

def es_transitiva(R):
    for (a, b) in R:
        for (x, c) in R:
            if b == x and (a, c) not in R:
                print(f"Verificacion fallida")
                return False
    print("Verificacion exitosa")
    return True

R_transitiva = clausura_transitiva(R)
es_transitiva(R_transitiva)