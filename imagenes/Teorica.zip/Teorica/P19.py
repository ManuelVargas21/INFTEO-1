print("Resultado de funcion biyectiva")
def f(x):
    return x + 1

A = range(0, 10)      
B = set(range(1, 11))  

imagen = [f(x) for x in A]

def es_biyectiva(B, imagen):
    return B.issubset(set(imagen)) and len(set(imagen)) == len(imagen)

print("Verificacion exitosa:", es_biyectiva(B, imagen))