numeros = list(range(1, 101))

print("Resultado de Infinitos")

print("Conjunto generado es:", numeros )

def verificar_tamaño(conjunto):
    
    return len(conjunto) == 100

if verificar_tamaño(numeros):
    print("El tamaño es de 100")
    
else:
    print("No mantiene el tamaño adecuado")