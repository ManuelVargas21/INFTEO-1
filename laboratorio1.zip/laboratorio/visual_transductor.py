"""
Proyecto: Transductor Visual Interactivo
Descripción:
Este programa simula gráficamente el funcionamiento de un transductor (o autómata finito no determinista).
Permite ingresar una cadena, observar los recorridos posibles paso a paso, y ver cuáles rutas son aceptadas.
Usa Python con Tkinter, Matplotlib y NetworkX para crear una simulación gráfica interactiva.
"""

import tkinter as tk
from tkinter import messagebox
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


class TransductorVisual:
    """Clase principal que modela, simula y visualiza el comportamiento de un transductor."""

    def __init__(self, master):
        """
        Constructor: inicializa la interfaz gráfica, el grafo y las variables principales.
        """
        self.master = master
        self.grafo = nx.DiGraph()  # Grafo dirigido (flechas con dirección)
        self.crear_grafo()  # Se definen estados y transiciones
        self.estados_iniciales = ['q0']
        self.estados_actuales = self.estados_iniciales.copy()
        self.cadena = ''
        # Historial de caminos recorridos (cada lista representa una ruta)
        self.recorridos = [[estado] for estado in self.estados_actuales]
        self.pausa = False  # Control de pausa

        # === INTERFAZ GRÁFICA ===
        self.label_estado = tk.Label(master, text=f"Estados actuales: {', '.join(self.estados_actuales)}")
        self.label_estado.pack()

        self.label_recorrido = tk.Label(master, text=f"Recorridos: {self.formatear_recorridos()}")
        self.label_recorrido.pack()

        # Entrada para escribir la cadena
        self.entry = tk.Entry(master)
        self.entry.pack()

        # Botones de control
        tk.Button(master, text="Iniciar", command=self.iniciar).pack()
        tk.Button(master, text="Pausar/Continuar", command=self.toggle_pausa).pack()
        tk.Button(master, text="Reiniciar", command=self.reiniciar).pack()

        # Área del grafo con Matplotlib
        self.fig, self.ax = plt.subplots(figsize=(5, 4))
        self.canvas = FigureCanvasTkAgg(self.fig, master=master)
        self.canvas.get_tk_widget().pack()

        # Dibujo inicial del grafo
        self.dibujar_grafo()

    # --------------------------------------------------------------------------

    def crear_grafo(self):
        """
        Define el grafo de estados y las transiciones del transductor.
        """
        # Aristas: relaciones entre estados
        self.grafo.add_edges_from([
            ('q0', 'q1'), ('q0', 'q2'),
            ('q1', 'q2'), ('q1', 'q1'),
            ('q2', 'q2')
        ])

        # Posición automática de los nodos
        self.pos = nx.spring_layout(self.grafo)

        # Diccionario de transiciones: estado → símbolo → lista de estados destino
        self.transiciones = {
            'q0': {'a': ['q1', 'q2']},
            'q1': {'b': ['q2'], 'a': ['q1']},
            'q2': {'a': ['q2']}
        }

        # Estado(s) de aceptación
        self.estados_aceptacion = ['q2']

    # --------------------------------------------------------------------------

    def dibujar_grafo(self, resaltado_edges=[]):
        """
        Dibuja el grafo de estados en la interfaz.
        Si se pasa una lista de aristas resaltadas, las muestra en rojo.
        """
        self.ax.clear()
        nx.draw(self.grafo, self.pos, ax=self.ax, with_labels=True,
                node_color='lightblue', edge_color='gray',
                node_size=1500, width=2)
        if resaltado_edges:
            nx.draw_networkx_edges(self.grafo, self.pos, edgelist=resaltado_edges,
                                   edge_color='red', width=3)
        self.canvas.draw()

    # --------------------------------------------------------------------------

    def iniciar(self):
        """
        Inicia la simulación leyendo la cadena ingresada por el usuario.
        """
        self.cadena = self.entry.get()
        self.estados_actuales = self.estados_iniciales.copy()
        self.recorridos = [[estado] for estado in self.estados_actuales]
        self.procesar_paso(0)  # Comienza desde el primer símbolo

    # --------------------------------------------------------------------------

    def procesar_paso(self, indice):
        """
        Procesa la cadena símbolo por símbolo, actualizando los recorridos posibles.
        Muestra gráficamente los pasos y resalta las transiciones activas.
        """
        # Caso base: si ya terminó la cadena
        if indice >= len(self.cadena):
            aceptadas = [r for r in self.recorridos if r[-1] in self.estados_aceptacion]
            rechazadas = [r for r in self.recorridos if r[-1] not in self.estados_aceptacion]

            # Función auxiliar para convertir rutas a texto ignorando None
            def ruta_a_texto(ruta):
                return ' → '.join([str(s) for s in ruta if s is not None])

            mensaje = "RESULTADOS:\n"
            mensaje += f"Aceptadas ({len(aceptadas)}): {[ruta_a_texto(r) for r in aceptadas]}\n"
            mensaje += f"Rechazadas ({len(rechazadas)}): {[ruta_a_texto(r) for r in rechazadas]}"

            messagebox.showinfo("Resultado", mensaje)
            return

        # Si está en pausa, esperar un poco y volver a intentar
        if self.pausa:
            self.master.after(500, lambda: self.procesar_paso(indice))
            return

        simbolo = self.cadena[indice]  # Símbolo actual
        nuevos_recorridos = []
        resaltado_edges = []

        # Recorre todos los caminos actuales
        for r in self.recorridos:
            estado_actual = r[-1]
            if estado_actual is None:
                nuevos_recorridos.append(r + [None])
                continue

            # Obtiene los posibles destinos para el símbolo
            destinos = self.transiciones.get(estado_actual, {}).get(simbolo, [])
            if not destinos:
                # No hay transición, camino termina
                nuevos_recorridos.append(r + [None])
            else:
                # Hay uno o más destinos (no determinismo)
                for d in destinos:
                    nuevos_recorridos.append(r + [d])
                    resaltado_edges.append((estado_actual, d))

        # Actualiza recorridos y estados actuales
        self.recorridos = nuevos_recorridos
        estados_actuales = set([r[-1] for r in self.recorridos if r[-1] is not None])
        self.estados_actuales = list(estados_actuales)

        # Actualiza las etiquetas de texto
        self.label_estado.config(
            text=f"Estados actuales: {', '.join(self.estados_actuales) if self.estados_actuales else 'Ninguno'}")
        self.label_recorrido.config(text=f"Recorridos: {self.formatear_recorridos()}")

        # Redibuja el grafo con las aristas resaltadas
        self.dibujar_grafo(resaltado_edges=resaltado_edges)

        # Llama de nuevo al método tras 1 segundo (animación paso a paso)
        self.master.after(1000, lambda: self.procesar_paso(indice + 1))

    # --------------------------------------------------------------------------

    def formatear_recorridos(self):
        """Convierte las listas de estados en texto legible para mostrarlas."""
        return '; '.join([' → '.join([str(s) for s in r if s is not None]) for r in self.recorridos])

    # --------------------------------------------------------------------------

    def toggle_pausa(self):
        """Activa o desactiva la pausa de la simulación."""
        self.pausa = not self.pausa

    # --------------------------------------------------------------------------

    def reiniciar(self):
        """Reinicia la simulación y devuelve todo al estado inicial."""
        self.estados_actuales = self.estados_iniciales.copy()
        self.recorridos = [[estado] for estado in self.estados_actuales]
        self.label_estado.config(text=f"Estados actuales: {', '.join(self.estados_actuales)}")
        self.label_recorrido.config(text=f"Recorridos: {self.formatear_recorridos()}")
        self.entry.delete(0, tk.END)
        self.dibujar_grafo()


# --------------------------------------------------------------------------
# Bloque principal: creación de la ventana y ejecución del programa
# --------------------------------------------------------------------------
if __name__ == "__main__":
    root = tk.Tk()
    root.title("Transductor Visual - Múltiples Recorridos")
    app = TransductorVisual(root)
    root.mainloop()
