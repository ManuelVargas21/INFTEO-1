import tkinter as tk
from tkinter import scrolledtext
from tkinter import messagebox

def detectar_vacia(cadena):
    """Evalua si una cadena es vacia"""
    if not cadena:
        return True, f"'{cadena}' es cadena vacia (ε). Longitud: {len(cadena)}"
    else:
        return False, f"'{cadena}' NO es cadena vacia. Longitud: {len(cadena)}"

def simular_concatenacion(S):
    """Muestra el comportamiento de ε como elemento neutro en concatenacion"""
    epsilon = "" 
    resultado1 = S + epsilon
    paso1 = f"Paso 1 (S + ε):\n'{S}' + '{epsilon}' = '{resultado1}'"

    resultado2 = epsilon + S
    paso2 = f"Paso 2 (ε + S):\n'{epsilon}' + '{S}' = '{resultado2}'"
    

    conclusion = (
        f"Conclusion:\n"
        f"Como '{resultado1}' == '{S}' y '{resultado2}' == '{S}', "
        f"la cadena vacía (ε) actua como el *elemento neutro* de la concatenación."
    )
    
    return [paso1, paso2, conclusion]

def ejecutar_simulacion():
    """Recoge la entrada y muestra los resultados en la interfaz."""
    S = entry_cadena.get()
    
    es_vacia, mensaje_deteccion = detectar_vacia(S)
    
    pasos_simulacion = simular_concatenacion(S)
    
    area_resultados.config(state=tk.NORMAL)
    area_resultados.delete(1.0, tk.END)
    
    area_resultados.insert(tk.END, "DETECCION DE LA CADENA VACIA\n")
    area_resultados.insert(tk.END, mensaje_deteccion + "\n\n")
    if es_vacia:
        area_resultados.insert(tk.END, "La cadena ingresada es ε, la simulación de neutralidad es trivial.\nSe procede a simular con la cadena vacía.\n\n")

    area_resultados.insert(tk.END, "SIMULACIÓN: ε COMO ELEMENTO NEUTRO\n")
    for paso in pasos_simulacion:
        area_resultados.insert(tk.END, paso + "\n\n")

    area_resultados.config(state=tk.DISABLED)

root = tk.Tk()
root.title("Deteccion y Simulacion de la Cadena Vacia")

tk.Label(root, text="Ingrese una Cadena (S):", font=('Arial', 10, 'bold')).pack(pady=5)
entry_cadena = tk.Entry(root, width=50)
entry_cadena.pack(pady=5, padx=10)
entry_cadena.insert(0, "Python")

tk.Button(root, text="Ejecutar AnAlisis y SimulaciOn", command=ejecutar_simulacion, bg='lightblue', font=('Arial', 10, 'bold')).pack(pady=10)

tk.Label(root, text="Resultados y Comportamiento Paso a Paso:", font=('Arial', 10, 'bold')).pack(pady=5)
area_resultados = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=60, height=15, font=('Consolas', 10))
area_resultados.pack(pady=10, padx=10)
area_resultados.config(state=tk.DISABLED)

ejecutar_simulacion()

root.mainloop()